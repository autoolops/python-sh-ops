#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author  : YongFu  Wang
# Time    : 2018/4/26 15:34
# FileName: main.py

import  os,sys

while True:
    print(
        '''
        #######################################################
        #           WELCOME  TO   ATM+SHOPPPING               #
        #                                                     #
        #           1.购物中心                                 #                                  
        #           2.信用卡中心                               #  
        #           3.后台管理                                 #
        #           b.exit                                    #
        #                                                     #
        #######################################################
        '''
    )
    choice_id = input("\33[34;0m选择要进入模式的ID\33[0m:").strip()
    if choice_id == "1":
        while True:
            print(
                '''
                #######################################################
                #                WELCOME  TO   购物中心                #
                #                                                     #
                #           1.购物商场                                 #
                #           2.查看购物车                               #
                #           3.购物结算                                 #
                #           4.个人中心                                 #
                #           5.返回('b')                                #
                #                                                     #
                #######################################################
                '''
            )
            choice_id = input("\33[34;0m选择要进入模式的ID\33[0m:").strip()
            if choice_id == '1':
                pass
            elif choice_id == '2':
                pass
            elif choice_id == '3':
                pass
            elif choice_id == '4':
                while True:
                    print(
                        '''
                        #######################################################
                        #                WELCOME  TO   个人中心                #
                        #                                                     #
                        #           1.购物历史记录                              #
                        #           2.修改登录密码                              #
                        #           3.修改个人信息                              #
                        #           4.修改行用卡绑定                            #
                        #           5.返回('b')                                #
                        #                                                     #
                        #######################################################
                        '''
                    )
                    choice_id = input("\33[34;0m选择要进入模式的ID\33[0m:").strip()
                    if choice_id == '1':
                        pass
                    elif choice_id == '2':
                        pass
                    elif choice_id == '3':
                        pass
                    elif choice_id == '4':
                        pass
                    elif choice_id == '5':
                        break
                    else:
                        print("\33[31;0m输入的ID无效，请重新选择\33[0m")

            elif choice_id == '5':
                break
            else:
                print("\33[34;0m输入的ID有误，请重新选择\33[0m:")
    elif choice_id == "2":
        while True:
            print(
                '''
                #######################################################
                #                WELCOME  TO  信用卡中心                #
                #                                                     #
                #           1.我的信用卡                                #
                #           2.提现                                     #
                #           3.转账                                     #
                #           4.还款                                     #
                #           5.流水记录                                  #
                #           b.返回                                     #
                #                                                     #
                #######################################################
                '''
            )
            choice_id = input("\33[34;0m选择要进入模式的ID\33[0m:").strip()
            if choice_id == '1':
                pass
            elif choice_id == '2':
                pass
            elif choice_id == '3':
                pass
            elif choice_id == '4':
                pass
            elif choice_id == '5':
                pass
            elif choice_id == 'b':
                break
            else:
                print("\33[34;0m输入的ID有误，请重新选择\33[0m:")

    elif choice_id == "3":
        while True:
            print(
                '''
                #######################################################
                #                WELCOME  TO  后台管理                 #
                #                                                     #
                #           1.创建账号                                 #
                #           2.锁定账号                                 #
                #           3.解锁账号                                 #
                #           4.发行信用卡                               #
                #           5.解冻信用卡                               #
                #           6.提升信用卡额度                            #
                #           b.返回                                     #
                #                                                     #
                #######################################################
                '''
            )
            choice_id = input("\33[34;0m选择要进入模式的ID\33[0m:").strip()
            if choice_id == '1':
                pass
            elif choice_id == '2':
                pass
            elif choice_id == '3':
                pass
            elif choice_id == '4':
                pass
            elif choice_id == '5':
                pass
            elif choice_id == 'b':
                break
            else:
                print("\33[34;0m输入的ID有误，请重新选择\33[0m:")

    elif choice_id == "b":
        break

    else:
        print("\33[34;0m输入的ID有误，请重新选择\33[0m:")



