#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author  : YongFu  Wang
# Time    : 2018/4/25 21:58
# FileName: auth.py
import os,json

'''装饰器'''

def  auth(auth_type):
    def  outer_wrapper(func):
        def wrapper(*args,**kwargs):
            if auth_type == "user_auth":
                username = input("\33[34;0m请输入用户名：\33[0m")
                if len(username.strip())>0:
                    with open('/Users/55haitao/Documents/python-sh-ops/day4/ATM/db/user_dict','r+') as  f_user_dict:
                        users_dict = json.loads(f_user_dict.read())
                        print(users_dict)
                        if username in users_dict.keys():
                            password = input("\33[34;0m请输入密码：\33[0m")
                            if password == users_dict[username]["password"]:
                                if users_dict[username]["locked"] == 0:
                                    print("\33[31;0m用户 %s 认证成功\33[0m" % (username))
                                    res = func(*args, **kwargs)
                                    return res,username
                                else:
                                    print("\33[31;0m用户 %s 已经被锁定 认证失败\33[0m" % (username))
                            else:
                                print("\33[31;0m输入的密码不匹配，请重新输入\33[0m")
                        else:
                            print("\33[31;0m输入的用户名不存在，请输入正确的用户名\33[0m")
                else:
                    print("\33[31;0m输入的用户名为空,请输入正确的用户名\33[0m")
        return wrapper
    return outer_wrapper


'''用户登录认证'''
@auth(auth_type="user_auth")
def user_auth():
    print("\33[32;0m用户登录认证\33[0m".center(40,"-"))
    return "test"

user_auth()

